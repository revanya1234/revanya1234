def linear search product(product list,target product):
indices=[]
for index,product in enumarate(product list):
if product==target product:
indices.append(index)
return indices
(variable)products:list(str)
products=("shoes",boot","
target="shoes
target2="apple"
result=(linear shoes product(product,target)
print(result)