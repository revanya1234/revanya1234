#define the base class player
class player:
    def play(self):
      print("the player is palying cricket.")
      #define the derived class bastman.")
      class bastman(player):
        def play(self):
          print("the bastmab is bating.")
          #define the derived class bastman
          class bastman(player):
            def play(self)
            print("the bastman is bowlling.")
            bastman=batsman()
            bowler=bowler()