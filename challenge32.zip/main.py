class student:
    def__int__(self,name,roll__number,(gpa)
               self.name=Name
  self.roll_number=roll_number
  self.cgpa=cgpa

  def sort_students(student_list):
    sorted_student=sorted(student_list;
    key=lambda student:student.cgpa,reverse=True
    reverse sorted_students
    students=[
    student("Hari","A123",7.8),
    student("Srikanth","A124",8.9),
    student("Saranya","A125",9.1),
    student("Mahindar","A126",9.9),
    ]
    sorted_students=sort_students(students)
    for student in sorted_students:
      print("name:{},roll number:{},cgpa:{}".format(students.name,student,roll_number,student.cgpa